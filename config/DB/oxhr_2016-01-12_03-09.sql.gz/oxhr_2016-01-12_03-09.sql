#SKD101|oxhr|10|2016.01.12 03:09:26|184|1|12|87|84

DROP TABLE IF EXISTS `phinxlog`;
CREATE TABLE `phinxlog` (
  `version` bigint(20) NOT NULL,
  `start_time` timestamp NOT NULL /*!40101 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP */,
  `end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `phinxlog` VALUES
(20160107224533, '2016-01-09 22:29:17', '2016-01-09 22:29:17');

DROP TABLE IF EXISTS `positions`;
CREATE TABLE `positions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `skills`;
CREATE TABLE `skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `skills_groups_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `skills_groups`;
CREATE TABLE `skills_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `specializations`;
CREATE TABLE `specializations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `specializations` VALUES
(1, 'PHP Web-developer', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(2, 'Ruby Web-developer', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(3, 'Python developer', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(4, 'JS Full Stack developer', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(5, 'Front-end developer', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(6, 'iOS developer', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(7, 'Android developer', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(8, 'DevOps', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(9, 'Java developer', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(10, 'QA', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(11, 'Project Manager (PM)', '2016-01-10 00:00:00', '2016-01-10 00:00:00'),
(12, 'Designer', '2016-01-10 00:00:00', '2016-01-10 00:00:00');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `email` varchar(150) NOT NULL,
  `gmail` varchar(150) NOT NULL,
  `skype` varchar(50) NOT NULL,
  `birthday` date NOT NULL,
  `ssh_key` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `table_num` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `users` VALUES
(1, 'anton.riabukha', 'empty password', 'Anton', 'Riabukha', 'anton.riabukha@onix-systems.com', 'sababa777@gmail.com', 'sababaanton', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 623),
(2, 'anthony', 'empty password', 'Anthony', 'Bazhuhin', 'anthony@onix-systems.com', 'anthony.bazhuhin@gmail.com', 'anthony.bazhuhin', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 855),
(3, 'alexandr.vachshenko', 'empty password', 'Alexander', 'Vashchenko', 'alexandr.vachshenko@onix-systems.com', 'aav.ukr@gmail.com', 'alex_aronskii', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', NULL),
(4, 'aleksandr.osipov', 'empty password', 'Aleksandr', 'Osipov', 'aleksandr.osipov@onix-systems.com', 'osipov.aleks.kr@gmail.com', 'aleksandr_oss', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 604),
(5, 'sasha', 'empty password', 'Alexander', 'Berdnikov', 'sasha@onix-systems.com', 'alexander.berdnikov.onix@gmail.com', 'ripxskype', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 618),
(6, 'alexander.gilyashov', 'empty password', 'Alexander', 'Gilyashov', 'alexander.gilyashov@onix-systems.com', 'gilyashov.alexandr@gmail.com', 'deadbyapril-_-', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 608),
(7, 'alexander', 'empty password', 'Alexander', 'Grushevoy', 'alexander@onix-systems.com', 'alexander.grushevoy@gmail.com', 'alexander.grushevoy', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 803),
(8, 'alexandr.vovk', 'empty password', 'Alexander', 'Vovk', 'alexandr.vovk@onix-systems.com', '', 'rackot.prog', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 106),
(9, 'alexandr.fedorenko', 'empty password', 'Alexandr', 'Fedorenko', 'alexandr.fedorenko@onix-systems.com', 'fedorenkoalex1992@gmail.com', 'fedorenkoalex1992', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 607),
(10, 'alexandr.zaretskii', 'empty password', 'Alexandr', 'Zareckii', 'alexandr.zaretskii@onix-systems.com', 'al.zaretskii@gmail.com', 'sa_sha_sa', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 107),
(11, 'alexei.nezhyborets', 'empty password', 'Alexey', 'Nezhiborets', 'alexei.nezhyborets@onix-systems.com', 'am.nezhyborets@gmail.com', 'undeadhip1', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 610),
(12, 'alexey.novikov', 'empty password', 'Alexey', 'Novikov', 'alexey.novikov@onix-systems.com', 'alekseeey@gmail.com', 'aleks...ey', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 828),
(13, 'voronoy', 'empty password', 'Alexey', 'Voronoy', 'voronoy@onix-systems.com', 'aleksey.voronoy@gmail.com', 'corbie_', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 621),
(14, 'andrey.ivanov', 'empty password', 'Andrey', 'Ivanov', 'andrey.ivanov@onix-systems.com', 'dzen.ivanov@gmail.com', 'dzen_ivan', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', NULL),
(15, 'andrew', 'empty password', 'Andrew', 'Tarasov', 'andrew@onix-systems.com', 'tarasov.andrew@gmail.com', 'tarasov.andrew', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 801),
(16, 'andrey.dyadyura', 'empty password', 'Andrey', 'Dyadura', 'andrey.dyadyura@onix-systems.com', 'andrey.dyadyura@onix-systems.com', 'woolfy_spasemarine', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 821),
(17, 'andrey.orel', 'empty password', 'Andrey', 'Orel', 'andrey.orel@onix-systems.com', 'Ashaman1991@gmail.com', 'ashaman1991', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 110),
(18, 'andy', 'empty password', 'Andy', 'Kramar', 'andy@onix-systems.com', 'andygo.develop@gmail.com', 'andykramar', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 838),
(19, 'anna.mezentseva', 'empty password', 'Anna', 'Mezentseva', 'anna.mezentseva@onix-systems.com', '', 'timkampy', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 634),
(20, 'anton.dolzhenko', 'empty password', 'Anton', 'Dolzhenko', 'anton.dolzhenko@onix-systems.com', 'dolzhenko.tony@gmail.com', 'dolzhenko_92', '0000-00-00', '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 615),
(21, 'artem.chaykovsky', 'empty password', 'Artem', 'Chaykovsky', 'artem.chaykovsky@onix-systems.com', 'artemchaykovsky@gmail.com', 'invisible_man14', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', NULL),
(22, 'boris.litvin', 'empty password', 'Boris', 'Litvin', 'boris.litvin@onix-systems.com', 'litvin.boris.onix.systems@gmail.com', 'nikborik', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 823),
(23, 'dmitry.akulich', 'empty password', 'Dmitry', 'Ackhulich', 'dmitry.akulich@onix-systems.com', 'akulich.dmitriy@gmail.com', 'akulich.dmitri', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 108),
(24, 'dmitriy.babiy', 'empty password', 'Dmitry', 'Babiy', 'dmitriy.babiy@onix-systems.com', 'y.filthpig.y@gmail.com', 'z.filthpig.z', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 612),
(25, 'dmitriy.kostinenko', 'empty password', 'Dmitry', 'Kostinenko', 'dmitriy.kostinenko@onix-systems.com', 'dik.work@gmail.com', 'dik_skype', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 624),
(26, 'dmitriy.kozlovskiy', 'empty password', 'Dmitry', 'Kozlovsky', 'dmitriy.kozlovskiy@onix-systems.com', 'argus.ua@gmail.com', 'argus_k', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 834),
(27, 'dmitry.nechessa', 'empty password', 'Dmitry', 'Nechessa', 'dmitry.nechessa@onix-systems.com', 'demetrius2004@gmail.com', 'dmitry.nechessa', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', NULL),
(28, 'dmitry.zenov', 'empty password', 'Dmitry', 'Zenov', 'dmitry.zenov@onix-systems.com', 'zenich75@gmail.com', 'zenich75', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 814),
(29, 'ekaterina.litvin', 'empty password', 'Ekaterina', 'Litvin', 'ekaterina.litvin@onix-systems.com', '', 'katherinel_mwp', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', NULL),
(30, 'evgen.dementev', 'empty password', 'Eugen', 'Dementjev', 'evgen.dementev@onix-systems.com', 'rizr91@gmail.com', 'rizr91', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 113),
(31, 'eugen.dzubenko', 'empty password', 'Eugen', 'Dzubenko', 'eugen.dzubenko@onix-systems.com', '1senjen1@gmail.com', 'senjen5', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 854),
(32, 'eugene.ghostishev', 'empty password', 'Eugene', 'Ghostishev', 'eugene.ghostishev@onix-systems.com', 'ghostishev@gmail.com', 'ghostishev', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 842),
(33, 'eugene', 'empty password', 'Eugene', 'Kuchansky', 'eugene@onix-systems.com', '', 'eugene_kch', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 103),
(34, 'evgen.obrezkov', 'empty password', 'Eugene', 'Obrezkov', 'evgen.obrezkov@onix-systems.com', 'ghaiklor@gmail.com', 'ghaiklor', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 114),
(35, 'levoshko.galina', 'empty password', 'Galina', 'Levoshko', 'levoshko.galina@onix-systems.com', 'levoshkog@gmail.com', 'Erika_Tejra', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 850),
(36, 'helen', 'empty password', 'Helen', 'Kozlovskaya', 'helen@onix-systems.com', 'helen.kitten@gmail.com', 'helen.kitten', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 830),
(37, 'igor.serbin', 'empty password', 'Igor', 'Serbin', 'igor.serbin@onix-systems.com', 'serbin.igor@gmail.com', 'serbin.i.v', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', NULL),
(38, 'igor.shpeka', 'empty password', 'Igor', 'Shpeka', 'igor.shpeka@onix-systems.com', 'micronick.pro@gmail.com', 'evil_ultra_fan', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 603),
(39, 'illya.levoshko', 'empty password', 'Ilya', 'Levoshko', 'illya.levoshko@onix-systems.com', 'illyalevoshko@gmail.com', 'ilevoshko', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 640),
(40, 'ivan', 'empty password', 'Ivan', 'Sagal', 'ivan@onix-systems.com', 'tzar.ivan@gmail.com', 'tsar-ivan', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 625),
(41, 'julia', 'empty password', 'Julia', 'Bazhuhina', 'julia@onix-systems.com', 'julia.bazhuhina@gmail.com', 'julia.bazhuhina', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 851),
(42, 'julia.nosko', 'empty password', 'Julia', 'Nosko', 'julia.nosko@onix-systems.com', 'gergardtjulia@gmail.com', 'little_angel2912', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 831),
(43, 'konstantin.batura', 'empty password', 'Konstantin', 'Batura', 'konstantin.batura@onix-systems.com', 'rustykoc@gmail.com', 'damnsneaker', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 105),
(44, 'konstantin.kovalenko', 'empty password', 'Konstantin', 'Kovalenko', 'konstantin.kovalenko@onix-systems.com', 'kovalenko.k.i@gmail.com', 'colizium', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 828),
(45, 'kostya.altuhov', 'empty password', 'Konstantin', 'Altuhov', 'kostya.altuhov@onix-systems.com', 'konstantin255@gmail.com', 'evne_altuhov', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 845),
(46, 'konstantin.svidzinskyi', 'empty password', 'Kostya', 'Svidsinskiy', 'konstantin.svidzinskyi@onix-systems.com', 'konstantin.svidzinskyi@gmail.com', 'design_future85', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 807),
(47, 'liya.lytvynenko', 'empty password', 'Liya', 'Lytvynenko', 'liya.lytvynenko@onix-systems.com', 'liya.lytvynenko@gmail.com', 'liyalytvynenko', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 817),
(48, 'mariya.pyanova', 'empty password', 'Mariya', 'Pyanova', 'mariya.pyanova@onix-systems.com', 'pyanovamary@gmail.com', 'fire_69_ice', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 843),
(49, 'maxim.kamenschikov', 'empty password', 'Maxim', 'Kamenschikov', 'maxim.kamenschikov@onix-systems.com', 'maximz.kam@gmail.com', 'maximz85', '0000-00-00', '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 806),
(50, 'maxim.nazarenko', 'empty password', 'Maxim', 'Nazarenko', 'maxim.nazarenko@onix-systems.com', 'maks.nazarenko@gmail.com', 'maksis86', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 827),
(51, 'misha', 'empty password', 'Mikhail', 'Holovlov', 'misha@onix-systems.com', '', 'holovlov', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', NULL),
(52, 'nastya.stifutina', 'empty password', 'Nastya', 'Stifutina', 'nastya.stifutina@onix-systems.com', 'stifutina@gmail.com', 'nasty_stifutina', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 820),
(53, 'kela', 'empty password', 'Nikolay', 'Makarevich', 'kela@onix-systems.com', 'makarevich.nikolay@gmail.com', 'nikolaymakarevich', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 809),
(54, 'oleg.adignalov', 'empty password', 'Oleg', 'Adignalov', 'oleg.adignalov@onix-systems.com', 'adignalov_oleg@mail.ru', 'nesh9111', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 815),
(55, 'oleg', 'empty password', 'Oleg', 'Chumachenko', 'oleg@onix-systems.com', 'oleg.ch.2009@gmail.com', 'oleg_chumachenko', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 812),
(56, 'oleg.gatseluk', 'empty password', 'Oleg', 'Gatseluk', 'oleg.gatseluk@onix-systems.com', 'metal.gvc@gmail.com', 'oleg_gatseluk', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 636),
(57, 'oleg.koval', 'empty password', 'Oleg', 'Koval', 'oleg.koval@onix-systems.com', 'oleh.koval95@gmail.com', 'oleh.koval95', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 620),
(58, 'oleg.romenskiy', 'empty password', 'Oleg', 'Romenskiy', 'oleg.romenskiy@onix-systems.com', 'kazimad.kr@gmail.com', 'kazimad.kr', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 602),
(59, 'oleg.tipa', 'empty password', 'Oleg', 'Tipa', 'oleg.tipa@onix-systems.com', 'murchibik@gmail.com', 'murchibik', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 804),
(60, 'oleksiy.tsabiy', 'empty password', 'Oleksiy', 'Tsabiy', 'oleksiy.tsabiy@onix-systems.com', 'alexeytsabiy@gmail.com', 'alexeytsabiy', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 853),
(61, 'roman.zagorsky', 'empty password', 'Roman', 'Zagorsky', 'roman.zagorsky@onix-systems.com', 'zagorskyi@gmail.com', 'zagorskyirm', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 601),
(62, 'sergey_f', 'empty password', 'Sergey', 'Fillipenko', 'sergey_f@onix-systems.com', 'sergey.filip@gmail.com', 'serg.filipenko', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 104),
(63, 'sergey', 'empty password', 'Sergey', 'Hrolikov', 'sergey@onix-systems.com', 'hrolikov.sergey@gmail.com', 'hrolikov.sergey', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 824),
(64, 'xain', 'empty password', 'Sergey', 'Kholin', 'xain@onix-systems.com', 'xain.onix@gmail.com', 'xain_se', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 819),
(65, 'sergey.kovalchuk', 'empty password', 'Sergey', 'Kovalchuk', 'sergey.kovalchuk@onix-systems.com', 'progsly@gmail.com', 'sergey-kovalchuk', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 841),
(66, 'sergey.naydenko', 'empty password', 'Sergey', 'Naydenko', 'sergey.naydenko@onix-systems.com', 'lancers0492@gmail.com', 'lancers92', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 839),
(67, 'sergey.romanenko', 'empty password', 'Sergey', 'Romanenko', 'sergey.romanenko@onix-systems.com', 'awilum.inc@gmail.com', 'awilum.s', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', NULL),
(68, 'serhii', 'empty password', 'Sergey', 'Shevchenko', 'serhii@onix-systems.com', 'serhii.onix@gmail.com', 'silverrain4', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 813),
(69, 'sergey.zhabotin', 'empty password', 'Sergey', 'Zhabotin', 'sergey.zhabotin@onix-systems.com', 'greyworden@gmail.com', 'zhsergzh', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 802),
(70, 'vadim.nikolaenko', 'empty password', 'Vadim', 'Nikolaenko', 'vadim.nikolaenko@onix-systems.com', 'vadimnikolaenko.biz@gmail.com', 'crazygrizli', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 863),
(71, 'valentin.dumareckii', 'empty password', 'Valentin', 'Dumareckii', 'valentin.dumareckii@onix-systems.com', 'dumareckii@gmail.com', 'dumareckii', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 609),
(72, 'valeriy.checha', 'empty password', 'Valeriy', 'Checha', 'valeriy.checha@onix-systems.com', 'chechavalera@gmail.com', 'chechavaleriy', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 837),
(73, 'valeriy.pogoniev', 'empty password', 'Valeriy', 'Pogoniev', 'valeriy.pogoniev@onix-systems.com', 'ever.shp@gmail.com', 'ever_shade', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 613),
(74, 'valeriy.zlenko', 'empty password', 'Valeriy', 'Zlenko', 'valeriy.zlenko@onix-systems.com', 'jgit.program@gmail.com', 'jgit_deter', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 616),
(75, 'vyacheslav.kramarenko', 'empty password', 'Viacheslav', 'Kramarenko', 'vyacheslav.kramarenko@onix-systems.com', '02cabeza@gmail.com', 'slk02perfecto', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 619),
(76, 'victor.nagorny', 'empty password', 'Victor', 'Nagorny', 'victor.nagorny@onix-systems.com', 'nagorny2009@gmail.com', 'victor_nagorny', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 847),
(77, 'vitaliy.kolodeev', 'empty password', 'Vitaliy', 'Kolodeev', 'vitaliy.kolodeev@onix-systems.com', 'uchihaveha@gmail.com', 'uchiha_veha', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 810),
(78, 'vitaliy.lavrinenko', 'empty password', 'Vitaliy', 'Lavrinenko', 'vitaliy.lavrinenko@onix-systems.com', 'vitlav90@gmail.com', 'lochi_loke', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 818),
(79, 'vitaliy.savchenko', 'empty password', 'Vitaliy', 'Savchenko', 'vitaliy.savchenko@onix-systems.com', 'vsviews@gmail.com', 'dominion1990', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 617),
(80, 'vlad.ukraintsev', 'empty password', 'Vlad', 'Ukraintsev', 'vlad.ukraintsev@onix-systems.com', 'mistlurker@gmail.com', 'vladosmangos77', '0000-00-00', '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 635),
(81, 'vladimir.bandurka', 'empty password', 'Vladimir', 'Bandurka', 'vladimir.bandurka@onix-systems.com', 'shadworktest@gmail.com', 'v.bandurka', '0000-00-00', '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 639),
(82, 'vladimir.gordienko', 'empty password', 'Vladimir', 'Gordienko', 'vladimir.gordienko@onix-systems.com', 'brightlycolor@gmail.com', 'gorduarabey', '0000-00-00', '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 622),
(83, 'vladimir.kalinichenko', 'empty password', 'Vladimir', 'Kalinichenko', 'vladimir.kalinichenko@onix-systems.com', 'qiper4life@gmail.com', 'qiper4life', '0000-00-00', '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 614),
(84, 'vladimir.perepelica', 'empty password', 'Vladimir', 'Perepelitsa', 'vladimir.perepelica@onix-systems.com', 'vladimirperepelitsa101@gmail.com', 'mr-skaz', '0000-00-00', '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 826),
(85, 'vladislav.baranchuk', 'empty password', 'Vladislav', 'Baranchuk', 'vladislav.baranchuk@onix-systems.com', 'kgrpwnz@gmail.com', 'kuguarpwnz', '0000-00-00', '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 857),
(86, 'vyacheslav.yarmak', 'empty password', 'Vyacheslav', 'Yarmak', 'vyacheslav.yarmak@onix-systems.com', 'evitageeens@gmail.com', 'spitfast', '0000-00-00', '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 822),
(87, 'sergey.slavin', 'empty password', 'Sergey', 'Slavin', 'sergey.slavin@onix-systems.com', 'slavin.dev@gmail.com', 'slavinsergey', '0000-00-00', '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', NULL);

DROP TABLE IF EXISTS `users_positions`;
CREATE TABLE `users_positions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `users_skills`;
CREATE TABLE `users_skills` (
  `user_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `level` int(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `users_specializations`;
CREATE TABLE `users_specializations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `descriptions` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `specialization_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `users_specializations` VALUES
(1, 1, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 11),
(2, 2, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 11),
(3, 3, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 6),
(4, 4, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 7),
(5, 5, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 6),
(6, 6, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 10),
(7, 7, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 6),
(8, 9, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 7),
(9, 10, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 1),
(10, 11, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 6),
(11, 12, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 1),
(12, 13, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 1),
(13, 14, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 7),
(14, 15, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 1),
(15, 16, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 1),
(16, 17, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 4),
(17, 18, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 1),
(18, 19, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 10),
(19, 20, '', '2016-01-11 23:07:27', '2016-01-11 23:07:27', 6),
(20, 21, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 6),
(21, 22, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 5),
(22, 23, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 4),
(23, 24, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 6),
(24, 25, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 1),
(25, 26, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 1),
(26, 27, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 1),
(27, 28, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 1),
(28, 29, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 12),
(29, 30, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 4),
(30, 31, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 1),
(31, 32, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 3),
(32, 33, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 3),
(33, 34, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 4),
(34, 35, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 10),
(35, 36, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 5),
(36, 37, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 7),
(37, 38, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 1),
(38, 39, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 11),
(39, 40, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 11),
(40, 41, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 2),
(41, 42, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 5),
(42, 43, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 4),
(43, 44, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 1),
(44, 45, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 1),
(45, 46, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 12),
(46, 47, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 11),
(47, 48, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 1),
(48, 49, '', '2016-01-11 23:07:28', '2016-01-11 23:07:28', 12),
(49, 50, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 8),
(50, 51, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(51, 52, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 5),
(52, 53, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 11),
(53, 54, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(54, 55, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(55, 56, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(56, 57, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 10),
(57, 58, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 7),
(58, 59, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(59, 60, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 2),
(60, 61, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 7),
(61, 63, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(62, 64, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 11),
(63, 65, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(64, 66, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 5),
(65, 67, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(66, 68, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 10),
(67, 69, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(68, 71, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 6),
(69, 72, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(70, 73, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 6),
(71, 74, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 10),
(72, 75, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 11),
(73, 76, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 2),
(74, 77, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 4),
(75, 78, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(76, 79, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 6),
(77, 80, '', '2016-01-11 23:07:29', '2016-01-11 23:07:29', 1),
(78, 81, '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 7),
(79, 82, '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 1),
(80, 83, '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 6),
(81, 84, '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 1),
(82, 85, '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 1),
(83, 86, '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 2),
(84, 87, '', '2016-01-11 23:07:30', '2016-01-11 23:07:30', 6);

